import ray
import argparse
from ray import serve


def parse_arguments():

    parser = argparse.ArgumentParser('Serve delete')

    parser.add_argument(
        '--name',
        type=str,
        required=True
    )

    args = parser.parse_args()

    return args

if __name__ == '__main__':
    ray.init(address='ray://localhost:10001')
    args = parse_arguments()
    serve.delete(args.name)
from ray import serve
from fastapi import FastAPI
import time


app = FastAPI()


@serve.deployment(
    ray_actor_options={"num_cpus": 0.2, "num_gpus": 0},
    autoscaling_config={
        "min_replicas": 0,
        "max_replicas": 4
    }
)
@serve.ingress(app)
class Translator:
    def __init__(self):
        self.name = 'Milad'

    @app.post("/")
    def translate(self, text: str) -> str:
        time.sleep(10)
        return f'{self.name} said: {text}'


translator_app = Translator.bind()
from ray import serve
from fastapi import FastAPI

app = FastAPI()


@serve.deployment(num_replicas=1, ray_actor_options={"num_cpus": 0.2, "num_gpus": 0})
@serve.ingress(app)
class Translator:
    def __init__(self):
        self.name = 'Milad'

    @app.post("/")
    def translate(self, text: str) -> str:
        return f'{self.name} said: {text}'


translator_app = Translator.bind()